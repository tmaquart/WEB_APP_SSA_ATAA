MINIMAL VERSIONS AND DEPENDENCIES

1- python 3.6.9 or higher
2- numpy
3- sys
4- matplotlib
5- mpl_toolkits.mplot3d
6- numpy-stl 2.11.2
7- scipy (full version only)

GET STARTED

1- run evaluation.py
2- modify as much as you want!
