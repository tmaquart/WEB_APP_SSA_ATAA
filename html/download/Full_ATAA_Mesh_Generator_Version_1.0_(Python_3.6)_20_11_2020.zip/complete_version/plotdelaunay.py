import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay

def plot3ddelaunayfunction(xvals,yvals,zvals,figurecounter):
	tri = Delaunay(np.array([xvals,yvals]).T)
	fig = plt.figure(figurecounter)
	ax = fig.add_subplot(1, 1, 1, projection='3d')
	ax.plot_trisurf(xvals, yvals, zvals, triangles=tri.simplices, cmap=plt.cm.Spectral)
	ax.set_xlabel('alpha_1')
	ax.set_ylabel('alpha_2')
	ax.set_zlabel('alpha_3')
	plt.title('alpha_1 vs alpha_2 vs alpha_3')
	plt.show()
