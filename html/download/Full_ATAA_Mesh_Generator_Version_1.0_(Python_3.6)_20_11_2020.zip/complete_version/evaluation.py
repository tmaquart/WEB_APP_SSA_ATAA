#full version 1.0
#created by T.MAQUART
#thanks to S.AVRIL and M.DI GIUSEPPE

########## IMPORTS ##########

from methods import *
from writemeshes import *
from buildingevaluation import *
from plot3dfile import *
from plotdelaunay import *
from plotstl import *
from plothist import *
import matplotlib.pyplot as plt
import sys

########## NOTES ##########

#1- Alpha_Mesh_i.txt files must contain only string + value per line
#2- CONNECTIVITY.cnc must contain only integers
#3- please read README.txt

########## INPUT ##########

#--- fixed parameters of SSA ---

reducedbasisprojection=10
if reducedbasisprojection < 1:
  print("ERROR")
  sys.exit()

#--- exporting modes option ---

exportmodes=True
modefactor=2000

#--- study type, 0 for systole, 1 for diastole ---

studytype=0

#--- connectivity parameters ---

connectivitycols=5

########## PROGRAM ##########

#--- study path ---

path="systole/"
if studytype==1:
	path="diastole/"

#--- reading from text files ---

singularvalues = readsingularvalues(1,path)
totalnumberofsnapshots=len(singularvalues)
#print("singular values: ", singularvalues)

leftvectors = readleftvectors(totalnumberofsnapshots,path)
#print("left vectors: ", leftvectors)
numberofvertices3times=len(leftvectors)

#useless here
#rightvectors = readrightvectors(totalnumberofsnapshots,path)
#print("right vectors: ", rightvectors)

alphasnapshotstab=[]
for i in range(0,totalnumberofsnapshots):
	alphasnapshotstab.append(readalphasnapshots(2,i,path))
	#print('alpha snapshot ' +  str(i) + ': ', alphasnapshotstab[i])

connectivity = readconnectivity(connectivitycols,path)
#print("connectivity: ", connectivity)
numberofelements=len(connectivity)
	
#--- geometric parameters min and max ---

alphasnapshotstabline=[]
for i in range(0,totalnumberofsnapshots):
	alphasnapshotstablinetmp=[]
	for j in range(0,totalnumberofsnapshots):
		alphasnapshotstablinetmp.append(alphasnapshotstab[j][i])
	alphasnapshotstabline.append(alphasnapshotstablinetmp)
	
maxalphatab=[]
minalphatab=[]
for i in range(0,totalnumberofsnapshots):
	maxalphatab.append(max(alphasnapshotstabline[i]))
	minalphatab.append(min(alphasnapshotstabline[i]))
	print('max alpha ' +  str(i+1) + ': ', maxalphatab[i])
	print('min alpha ' +  str(i+1) + ': ', minalphatab[i])
	
#--- evaluation parameters ---

alphas=[]
for i in range(0,reducedbasisprojection):
	alphas.append(input('enter alpha ' + str(i+1) + ': '))

#--- compute evaluation ---

vertices=evaluategeometry(alphas,leftvectors,numberofvertices3times)

#--- write evaluated mesh as OBJ ---

writeobj(connectivity,numberofvertices3times,numberofelements,vertices,path)

#--- 2D plots ---

figurecounter=1
for i in range(0,reducedbasisprojection-1):
	plt.figure(figurecounter)
	plt.plot(alphasnapshotstabline[0], alphasnapshotstabline[1+i], linestyle = 'none', marker = 'o', c = 'lime', markersize = 10)
	plt.xlim(minalphatab[0]-0.1*abs(minalphatab[0]), maxalphatab[0]+0.1*abs(maxalphatab[0]))
	plt.ylim(minalphatab[1+i]-0.1*abs(minalphatab[1+i]), maxalphatab[1+i]+0.1*abs(maxalphatab[1+i]))
	plt.xlabel('alpha_1')
	plt.ylabel('alpha_2')
	plt.title('alpha_1 vs alpha_' + str(i+2))
	plt.show()
	figurecounter+=1

#--- histograms ---

for i in range(0,reducedbasisprojection):
	plothist(i+1,alphasnapshotstabline[i],figurecounter+i,minalphatab[i],maxalphatab[i])
figurecounter+=reducedbasisprojection

#--- 3D plot for alpha_1 alpha_2 and alpha_3 ---

plot3dfunction(alphasnapshotstabline[0], alphasnapshotstabline[1], alphasnapshotstabline[2],figurecounter)
figurecounter+=1

#--- 3D delaunay plot: useless for this study, depending on sampling ---

plot3ddelaunayfunction(alphasnapshotstabline[0], alphasnapshotstabline[1],alphasnapshotstabline[2],figurecounter)
figurecounter+=1

#--- write STL file ---

writestl(connectivity,vertices,numberofvertices3times,numberofelements,path)

#--- plot STL file ---

plotstlfunction(path,figurecounter)
figurecounter+=1

#--- modes ---

if exportmodes:
	for i in range(0,reducedbasisprojection):
		mode=[]
		for j in range(0,numberofvertices3times):
			mode.append(leftvectors[j][i])
		writeobjmodes(connectivity,numberofvertices3times,numberofelements,mode,i+1,modefactor,path)

#--- plot singular values ---

plt.figure(figurecounter)
xaxis = np.linspace(1, totalnumberofsnapshots, totalnumberofsnapshots)
plt.plot(xaxis, singularvalues, linestyle = '-', marker = 'o', c = 'b', markersize = 10)
plt.xlabel('index')
plt.ylabel('value')
plt.title('singular values')
plt.show()

