import matplotlib.pyplot as plt

def plothist(alphanumber,alphaplot,figurecounter,minalpha,maxalpha):
	plt.figure(figurecounter)
	plt.hist(alphaplot, range = (minalpha, maxalpha), bins = 7, color = 'yellow', edgecolor = 'red')
	plt.xlabel('values')
	plt.ylabel('number')
	plt.title('histogram alpha ' + str(alphanumber))
	plt.show()
