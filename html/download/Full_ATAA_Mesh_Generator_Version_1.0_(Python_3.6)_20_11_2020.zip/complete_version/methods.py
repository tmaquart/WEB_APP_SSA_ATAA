import numpy as np

def readleftvectors(totalnumberofsnapshots,path):
    leftvectors = np.loadtxt(path + 'left.txt', usecols=range(totalnumberofsnapshots))
    return leftvectors
	
def readrightvectors(totalnumberofsnapshots,path):
    rightvectors = np.loadtxt(path + 'right.txt', usecols=range(totalnumberofsnapshots))
    return rightvectors
	
def readsingularvalues(singulartype,path):
    singularvalues = np.loadtxt(path + 'singular.txt', usecols=range(singulartype))
    return singularvalues
	
def readalphasnapshots(alphatype, snapshotnumber,path):
    alphasnapshots = np.loadtxt(path + 'Alpha_Mesh_'+ str(snapshotnumber)+'.txt', usecols=range(1,alphatype))
    return alphasnapshots
	
def readconnectivity(connectivitycols,path):
    connectivity = np.loadtxt(path + 'CONNECTIVITY.cnc', usecols=range(connectivitycols))
    return connectivity
