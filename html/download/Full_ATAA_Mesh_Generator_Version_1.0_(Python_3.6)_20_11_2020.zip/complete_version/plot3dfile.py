import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def plot3dfunction(xvals,yvals,zvals,figurecounter):
	fig = plt.figure(figurecounter)
	ax = Axes3D(fig)
	ax.scatter(xvals, yvals, zvals)
	ax.set_xlabel('alpha_1')
	ax.set_ylabel('alpha_2')
	ax.set_zlabel('alpha_3')
	plt.title('alpha_1 vs alpha_2 vs alpha_3')
	plt.show()
