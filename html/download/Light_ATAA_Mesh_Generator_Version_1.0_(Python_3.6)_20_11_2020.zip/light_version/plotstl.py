from stl import mesh
from mpl_toolkits import mplot3d
import matplotlib.pyplot as plt

def plotstlfunction(path,figurecounter):
	figure = plt.figure(figurecounter)
	axes = mplot3d.Axes3D(figure)
	your_mesh = mesh.Mesh.from_file(path + 'iso.stl')
	axes.add_collection3d(mplot3d.art3d.Poly3DCollection(your_mesh.vectors))
	scale = your_mesh.points.flatten('C')
	axes.auto_scale_xyz(scale, scale, scale)
	axes.set_xlabel('x')
	axes.set_ylabel('y')
	axes.set_zlabel('z')
	plt.title('statistically evaluated geometry')
	plt.show()
