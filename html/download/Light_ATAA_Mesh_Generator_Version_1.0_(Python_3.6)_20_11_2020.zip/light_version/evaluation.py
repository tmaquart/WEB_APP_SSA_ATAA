#light version 1.0
#created by T.MAQUART
#thanks to S.AVRIL and M.DI GIUSEPPE

########## IMPORTS ##########

from methods import *
from writemeshes import *
from buildingevaluation import *
from plotstl import *
import sys

########## NOTES ##########

#1- Alpha_Mesh_i.txt files must contain only string + value per line
#2- CONNECTIVITY.cnc must contain only integers
#3- please read README.txt

########## INPUT ##########

#--- fixed parameters of SSA ---

totalnumberofsnapshots=24
reducedbasisprojection=10
if reducedbasisprojection < 1:
  print("ERROR")
  sys.exit()

#--- study type, 0 for systole, 1 for diastole ---

studytype=0

#--- connectivity parameters ---

connectivitycols=5

########## PROGRAM ##########

#--- study path ---

path="systole/"
if studytype==1:
	path="diastole/"

#--- reading from text files ---

leftvectors = readleftvectors(totalnumberofsnapshots,path)
numberofvertices3times=len(leftvectors)

alphasnapshotstab=[]
for i in range(0,totalnumberofsnapshots):
	alphasnapshotstab.append(readalphasnapshots(2,i,path))

connectivity = readconnectivity(connectivitycols,path)
numberofelements=len(connectivity)
	
#--- geometric parameters min and max ---

alphasnapshotstabline=[]
for i in range(0,totalnumberofsnapshots):
	alphasnapshotstablinetmp=[]
	for j in range(0,totalnumberofsnapshots):
		alphasnapshotstablinetmp.append(alphasnapshotstab[j][i])
	alphasnapshotstabline.append(alphasnapshotstablinetmp)
	
maxalphatab=[]
minalphatab=[]
for i in range(0,totalnumberofsnapshots):
	maxalphatab.append(max(alphasnapshotstabline[i]))
	minalphatab.append(min(alphasnapshotstabline[i]))
	
#--- evaluation parameters ---

alphas=[]
for i in range(0,reducedbasisprojection):
	alphas.append(input('enter alpha ' + str(i+1) + ': '))

#--- compute evaluation ---

vertices=evaluategeometry(alphas,leftvectors,numberofvertices3times)

#--- write evaluated mesh as OBJ ---

writeobj(connectivity,numberofvertices3times,numberofelements,vertices,path)

#--- write STL file ---

writestl(connectivity,vertices,numberofvertices3times,numberofelements,path)

#--- plot STL file ---

plotstlfunction(path,1)

